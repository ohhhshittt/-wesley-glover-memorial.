SETUP

1. Upload index.html and preview.jpg to the same GitHub repository.
2. Turn on GitHub Pages for the repository.
3. Your site URL will look like:
   https://YOUR-USERNAME.github.io/YOUR-REPO-NAME
4. Edit index.html and replace every instance of:
   YOUR_SITE_URL
   with your exact GitHub Pages URL (no trailing slash).
5. Commit/save the changes.
6. Send the GitHub Pages URL in iMessage.

The link preview and the page itself both use the same Wesley memorial image and wording.
